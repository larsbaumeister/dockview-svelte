<script lang="ts">
    import type { GroupPanelPartInitParameters } from "dockview-core";

    const params: GroupPanelPartInitParameters = $props();
</script>

{ JSON.stringify(params) }
<h1>Info { params.params.name }</h1>