<script>
    import DockView from "$lib/DockView.svelte";

</script>
<div class="w-screen h-screen">
    <DockView></DockView>
</div>